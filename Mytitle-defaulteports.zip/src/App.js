import * as React from 'react';
import {View,Text,StatusBar,ScrollView} from 'react-native'
import Header from './common/Header'
import Footer from './common/Footer'
import Mycard from './common/Mycard'
export default function Main() {
  return (
    <View>
    	<StatusBar/>
    	<Header />
    	<ScrollView>
    		<Mycard />
    		<Mycard />
    		<Mycard />
    		<Mycard />
    		<Mycard />
    		<Text>welcome</Text>
    	</ScrollView>
    	<Footer/>
    </View>
  );
}