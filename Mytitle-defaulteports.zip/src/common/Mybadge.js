import * as React from 'react';
import { Badge } from 'react-native-paper';

const Mybadge = () => (
  <Badge>3</Badge>
);

export default Mybadge;