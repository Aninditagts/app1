import * as React from 'react';
import { Headline } from 'react-native-paper';

const Myheadline = () => (
  <Headline>Headline</Headline>
);

export default Myheadline;