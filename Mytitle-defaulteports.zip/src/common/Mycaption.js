import * as React from 'react';
import { Caption } from 'react-native-paper';

const Mycapion = () => (
  <Caption>Caption</Caption>
);

export default Mycapion;