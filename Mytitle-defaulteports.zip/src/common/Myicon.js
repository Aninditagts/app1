import * as React from 'react';
import { Avatar } from 'react-native-paper';

const Myicon = () => (
  <Avatar.Icon size={24} icon="folder" />
);
export default Myicon