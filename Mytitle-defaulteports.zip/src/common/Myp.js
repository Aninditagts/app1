import * as React from 'react';
import { Paragraph } from 'react-native-paper';

const Myp = () => (
  <Paragraph>Paragraph</Paragraph>
);

export default Myp;