import * as React from 'react';
import { Subheading } from 'react-native-paper';

const MyComponent = () => (
  <Subheading>Subheading</Subheading>
);

export default MyComponent;