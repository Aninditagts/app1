import React from 'react'
import data from './data'
import { View, Text, Button, StyleSheet, TextInput, Image, ScrollView } from 'react-native'
import { Asset, AppLoading } from 'expo';
function App() {
	return <View>
			<Text>welcome paper</Text>
	</View>
}
export default App
