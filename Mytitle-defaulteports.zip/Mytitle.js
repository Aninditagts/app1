import * as React from 'react';
import { Title } from 'react-native-paper';

const MyComponent = () => (
  <Title>Title</Title>
);

export default MyComponent;